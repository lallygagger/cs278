/**
 * Spring MVC REST controllers.
 */
package org.jhipster.com.web.rest;
