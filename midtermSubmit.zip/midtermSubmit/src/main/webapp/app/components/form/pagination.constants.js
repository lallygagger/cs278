(function() {
    'use strict';

    angular
        .module('midtermApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
